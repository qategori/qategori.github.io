/* tema + penanda (bookmark), versi statis */
(function(){
  var nB=document.body;
  function ls(k,v){try{if(v===undefined)return localStorage.getItem(k);localStorage.setItem(k,v)}catch(e){return null}}
  window.setTheme=function(m){
    var v=(m==='dark'||m==='light')?m:'default';
    ls('q_theme',v);nB.setAttribute('data-theme',v);
    if(v==='default')document.documentElement.removeAttribute('data-q');else document.documentElement.setAttribute('data-q',v);
    var c=document.getElementById('forDark');if(c)c.checked=false;
  };
  var DEL=/*DELSVG*/;
  function load(){try{return JSON.parse(ls('ignielBookmark'))||[]}catch(e){return[]}}
  function save(a){ls('ignielBookmark',JSON.stringify(a))}
  function esc(s){return String(s).replace(/[&<>"]/g,function(c){return{'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]})}
  function bid(p){return String(p).replace(/\W/g,'').slice(-24)}
  var ICONS=/*BMSVG*/;
  window.qBmBtn=function(path,title,img){
        var id=bid(path);
    return '<div class="ignielBookmarkPost tag addl"><input class="hidden addb" id="bm-'+id+'" name="bookmark" type="checkbox"><label aria-label="Tambah penanda" class="flex center op i16" data-img="'+esc(img||'')+'" data-title="'+esc(title)+'" data-url="'+esc(path)+'" for="bm-'+id+'">'+ICONS+'</label></div>';
  };
  function render(){
    var a=load(),inner=document.querySelector('.bookmark-inner'),bc=document.querySelector('.ignielBookmark label.bc');
    if(bc)bc.setAttribute('data-text',a.length);
    var all=document.querySelector('.ignielBookmarks'),page=location.pathname==='/p/bookmark.html'||!!all;
    var max=page?100:5,h=a.slice(0,max).map(function(e){
      return '<div class="flex" data-id="'+esc(e.id)+'"><div class="bm-thumb shrink"><a href="'+esc(e.url)+'"><img class="bm-im" loading="lazy" alt="'+esc(e.title)+'" src="'+esc(e.img||'')+'"></a></div><div class="bm-title grow"><a class="clamp" href="'+esc(e.url)+'" title="'+esc(e.title)+'">'+esc(e.title)+'</a></div><div class="bm-delete flex center shrink op i18" role="button">'+DEL+'</div></div>'}).join('');
    var empty='<span class="fontM">Belum ada penanda</span>';
    if(inner){
      if(!a.length)inner.innerHTML=empty;
      else if(page)inner.innerHTML='<span class="fontM">Anda sedang di laman Daftar Bacaan</span>';
      else inner.innerHTML='<div class="book flex column">'+h+'</div>'+(a.length>max?'<div class="more fontS"><a href="/p/bookmark.html"><span>Tampilkan</span><span class="fontSm opacity">(+'+(a.length-max)+')</span></a></div>':'');
    }
    if(all)all.innerHTML=a.length?'<div class="book all flex wrap">'+h+'</div>':empty;
    sync();
  }
  function sync(){
    var ids={};load().forEach(function(e){ids[e.id]=1});
    document.querySelectorAll('.ignielBookmarkPost input').forEach(function(i){i.checked=!!ids[i.id.replace('bm-','')]});
  }
  document.addEventListener('change',function(ev){
    var i=ev.target;if(!i.matches||!i.matches('.ignielBookmarkPost input'))return;
    var id=i.id.replace('bm-',''),l=i.parentNode.querySelector('label'),a=load(),k=a.findIndex(function(e){return e.id===id});
    if(k>=0)a.splice(k,1);else a.push({id:id,img:l.getAttribute('data-img'),title:l.getAttribute('data-title'),url:l.getAttribute('data-url')});
    save(a);render();
  });
  document.addEventListener('click',function(ev){
    var d=ev.target.closest&&ev.target.closest('.bm-delete');if(!d)return;
    var id=d.parentNode.getAttribute('data-id');save(load().filter(function(e){return e.id!==id}));render();
  });
  var mo=new MutationObserver(function(){clearTimeout(mo.t);mo.t=setTimeout(function(){var al=document.querySelector('.ignielBookmarks');if(al&&/Memuat daftar penanda/.test(al.textContent))render();else sync()},80)});
  mo.observe(document.body,{childList:true,subtree:true});
  /* tutup popup tema/penanda kalau tap di luar */
  document.addEventListener('click',function(ev){
    var t=ev.target;if(!t.closest)return;
    if(t.closest('.settB')||t.closest('.headB')||t.closest('.bm-delete'))return;
    var cp=t.closest('[data-copy]');if(cp){var inp=document.getElementById('getLink');if(inp){try{navigator.clipboard.writeText(inp.value)}catch(e){inp.select();try{document.execCommand('copy')}catch(e2){}}cp.textContent='Tersalin';setTimeout(function(){cp.textContent='Salin'},1500)}return}
    var sh=document.getElementById('forShare');if(sh&&sh.checked&&t.id!=='forShare'&&!t.closest('.shareB .popIn')&&!t.closest('.qShare')){sh.checked=false}
    ['forDark','forBook'].forEach(function(id){var c=document.getElementById(id);if(c&&c.checked)c.checked=false});
  });
  /* hanya satu popup terbuka */
  document.addEventListener('change',function(ev){
    var t=ev.target;if(t.id==='forDark'&&t.checked){var b=document.getElementById('forBook');if(b)b.checked=false}
    if(t.id==='forBook'&&t.checked){var d=document.getElementById('forDark');if(d)d.checked=false}
  });
  render();
})();

/* Mochi & tombol Suasana tidak boleh menutupi footer (sosmed & kredit): naik di atas garis footer */
(function(){
  var ids=['qcat','qfxFab'],raf=0;
  function run(){
    raf=0;
    var f=document.querySelector('.qFoot'),line=f?f.getBoundingClientRect().top:1e9;
    ids.forEach(function(id){
      var e=document.getElementById(id);if(!e)return;
      var cur=parseFloat(e.style.getPropertyValue('--qlift'))||0;
      var r=e.getBoundingClientRect();if(!r.width)return;
      var base=r.bottom+cur,lim=line-8,need=base>lim?Math.ceil(base-lim):0;
      if(need!==cur){if(need)e.style.setProperty('--qlift',need);else e.style.removeProperty('--qlift')}
    });
  }
  function q(){if(!raf)raf=requestAnimationFrame(run)}
  addEventListener('scroll',q,{passive:true});addEventListener('resize',q);
  addEventListener('load',q);setInterval(q,1000);q();
})();
