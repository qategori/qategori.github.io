import re
def open_access(h):
    """Materi terbuka untuk semua; kuis: Paket 1 gratis (tamu/login biasa), Paket 2+ wajib anggota/bayar."""
    if 'khusus anggota' not in h: return h
    nq=h.count('async function onUser(user){')
    def rep(old,new,cnt=nq,regex=False):
        nonlocal h
        if regex:
            h,k=re.subn(old,new,h)
        else:
            k=h.count(old); h=h.replace(old,new)
        assert k==cnt,(old[:60],k,cnt)
    # --- materi: selalu tampil ---
    rep("onAuthStateChanged(auth, function(user){\n    __authUser = user;\n    if (!user) { viewLogin(); return; }\n    checkAccess(user);\n  });",
        "onAuthStateChanged(auth, function(user){\n    __authUser = user;\n    showContent(); /* materi terbuka untuk semua */\n  });")
    # --- kuis ---
    rep("if (!user) return viewLogin();","if (!user) { S.role = 'free'; return viewMenu(); }")
    rep("return deniedBidang ? viewDeniedBidang() : viewDenied();","S.role = 'free'; return viewMenu();")
    # loadBank: tamu/free hanya baca Paket 1 (no <= 100)
    def lb(m):
        b=m.group(0)
        b2=re.sub(r"const snap = await getDocs\(collection\(db, '(\w+)'\)\);",
                  lambda k:"const snap = await getDocs(S.role === 'free' ? query(collection(db, '%s'), where('no', '<=', 100)) : collection(db, '%s'));"%(k.group(1),k.group(1)),b,count=1)
        b2=b2.replace(".sort((a, b) => (a.no || 0) - (b.no || 0));",".sort((a, b) => (a.no || 0) - (b.no || 0)).filter(q => S.role !== 'free' || q._paket === 1);",1)
        assert b2!=b and 'filter(q =>' in b2 and "where('no'" in b2
        return b2
    h,k=re.subn(r"async function loadBank\(\)\{.*?\n\}\n",lb,h,flags=re.S); assert k==nq,(k,nq)
    rep("const first = (S.user.displayName || S.user.email).split(/[ @]/)[0];","const first = S.user ? (S.user.displayName || S.user.email).split(/[ @]/)[0] : 'Tamu';")
    rep("try { await loadBank(); } catch (err) { console.error(err); return viewError('Gagal memuat soal.', err); }",
        "try { await loadBank(); } catch (err) { console.error(err); return viewError(S.role === 'free' && err && err.code === 'permission-denied' ? 'Paket 1 belum dibuka untuk umum (aturan Firestore belum diubah admin).' : 'Gagal memuat soal.', err); }")
    rep('<button class="ghost" data-action="history">Riwayat skor</button>',
        "${S.user ? '<button class=\"ghost\" data-action=\"history\">Riwayat skor</button>' : ''}")
    lock=("${S.role === 'free' ? `<div class=\"card\" style=\"margin:14px 0;text-align:center\"><p><strong>Paket 1 gratis.</strong> Paket 2 dan seterusnya berbayar.</p>"
          "<button class=\"btn\" data-action=\"${S.user ? 'pay' : 'goLogin'}\">${S.user ? 'Bayar untuk buka Paket 2+' : 'Masuk untuk membeli Paket 2+'}</button>"
          "<p class=\"kd-note\" id=\"pay-note\"></p></div>` : ''}\n    ")
    rep('<div style="height:14px"></div>\n    <button class="btn" data-action="start">Mulai kuis</button>',
        lock+'<div style="height:14px"></div>\n    <button class="btn" data-action="start">Mulai kuis</button>')
    rep("  try {\n    await addDoc(collection(db, 'results",
        "  if (!S.user) { const n0 = $('#saved'); if (n0) n0.textContent = 'Masuk untuk menyimpan riwayat skor.'; return; }\n  try {\n    await addDoc(collection(db, 'results")
    rep("showEmailForm(){ loginMode = 'signin'; viewLogin(); },",
        "showEmailForm(){ loginMode = 'signin'; viewLogin(); },\n  goLogin(){ loginMode = 'choice'; viewLogin(); },\n  toMenu(){ onUser(S.user); },")
    rep("<p>Halaman ini khusus anggota. Masuk dengan akun Google atau Email yang sudah didaftarkan admin.</p>\n    ${loginMode === 'choice'",
        "<p>Masuk untuk membeli akses Paket 2 dan seterusnya. Paket 1 gratis tanpa login.</p>\n    ${loginMode === 'choice'")
    rep('<p class="err" id="err">${esc(msg)}</p></section>`);',
        '<p class="err" id="err">${esc(msg)}</p><button class="switch" data-action="toMenu">&larr; Kembali ke Paket 1 (gratis)</button></section>`);')
    return h
