# Qategori — repo sumber + CMS

Isi: `content/posts` (artikel), `content/pages` (halaman), `config/layout.json` (layout),
`content/img` (gambar), `build.py` (generator), `admin/` (CMS, tampil di https://www.qategori.com/admin/).

## Setup sekali saja
1. Buat repo **private** baru, mis. `qategori/site-src`. Upload seluruh isi folder ini (termasuk `.github`), branch `main`.
2. Buat token **DEPLOY** (Settings → Developer settings → Fine-grained tokens): akses hanya repo `qategori/qategori.github.io`, izin **Contents: Read and write**.
   Simpan di repo sumber: Settings → Secrets and variables → Actions → New secret → nama `DEPLOY_TOKEN`.
3. Repo `qategori/qategori.github.io` → Settings → Pages → Source: *Deploy from a branch* → `main` / root. Custom domain `www.qategori.com`, Enforce HTTPS.
4. Buat token **CMS** (fine-grained): akses hanya repo `qategori/site-src`, izin **Contents: Read and write** + **Actions: Read**.
5. Buka https://www.qategori.com/admin/ → Pengaturan → tempel token CMS, isi repo `qategori/site-src`, branch `main` → Simpan & uji.

## Cara pakai
- Artikel → + Baru → tulis (Compose atau HTML) → Terbitkan. Tunggu ±1–2 menit; status build tampil di pojok kanan atas.
- Layout → ubah urutan/tampil beranda & sidebar, tautan info, video iklan, tombol sosial → Simpan layout.
- Bisa juga edit file JSON langsung di GitHub; build jalan otomatis.

## Catatan
- Halaman `/admin/` terbuka untuk umum tapi tanpa token tidak bisa apa-apa. Jangan simpan token di komputer bersama.
- Token CMS cuma tersimpan di browser (localStorage). Kalau bocor, cabut di GitHub.
- Folder `admin/` di repo situs publik ikut ter-deploy; tidak berisi rahasia.

## Update kode lewat zip (otomatis unpack)
Upload `qategori-src.zip` ke root repo ini (branch `main`). Workflow Build & Deploy akan unpack, menghapus zip, lalu build & deploy sendiri.
- Kode (build.py, admin/, app.js, dll) diganti dengan versi di zip.
- `content/` (artikelmu) dan `config/` (layout) TIDAK ditimpa; hanya file baru yang ditambahkan.
- Folder `.github` tidak ikut diupdate dari zip (GitHub menolak workflow diubah lewat token bawaan). Kalau `build.yml` berubah, salin manual.
