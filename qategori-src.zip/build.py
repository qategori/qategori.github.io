import re,json,os,shutil,html,urllib.parse,datetime
ROOT=os.path.dirname(os.path.abspath(__file__))
THEME=ROOT+'/theme/theme.xml'
OUT=ROOT+'/dist'
DOMAIN='https://www.qategori.com'   # dipakai di canonical/sitemap (domain nanti)
NAME='Qategori'
DESC_SITE='Update teknologi terkini: Android OS, iOS, review gadget, tips smartphone, dan info game PC/konsol. Baca tiap hari di Qategori.'
GA='G-80VVGYXJ4F'
shutil.rmtree(OUT,ignore_errors=True); os.makedirs(OUT)

t=open(THEME,encoding='utf8').read()
# ---------- CSS dasar dari skin tema ----------
s=t.index("<b:skin version='1.3.3'><![CDATA[")+len("<b:skin version='1.3.3'><![CDATA[")
e=t.index("]]></b:skin>")
skin=t[s:e]
V={m.group(1):m.group(2) for m in re.finditer(r'<Variable name="([^"]+)"[^>]*? value="([^"]*)"',skin)}
def rv(m):
    return V.get(m.group(1),m.group(0))
for _ in range(3): skin=re.sub(r'\$\(([A-Za-z0-9_.]+)\)',rv,skin)
i=t.index('<style>/*<![CDATA[*/',e)+len('<style>/*<![CDATA[*/'); j=t.index('/*]]>*/',i)
fonts=t[i:j]
base_css=skin+"\n"+fonts
# ambil blok CSS beranda bertab (#qHome ...) dari tema agar tampilan sama
qh=[l for l in t.split('\n') if l.startswith('#qHome') or l.startswith('.qh') or l.startswith('@media screen and (max-width:896px){#qHome') or '.qhPane' in l[:40] or '.qhGame' in l[:40]]
qhcss="\n".join(qh)
open(OUT+'/base.css','w',encoding='utf8').write(base_css+"\n/* beranda */\n"+qhcss)

# ---------- data ----------
def load_items():
    out=[]
    for dr in ('posts','pages'):
        base=ROOT+'/content/'+dr
        if not os.path.isdir(base): continue
        for fn in sorted(os.listdir(base)):
            if not fn.endswith('.json'): continue
            it=json.load(open(base+'/'+fn,encoding='utf8'))
            if it.get('draft'): continue
            it.setdefault('type','POST' if dr=='posts' else 'PAGE'); it.setdefault('labels',[]); it.setdefault('desc',''); it.setdefault('upd',it.get('pub',''))
            out.append(it)
    return out
items=load_items()
# ---------- layout (diatur lewat CMS: config/layout.json) ----------
LAY_DEF={'home':{'order':['mochi','ringkasan','berita'],'off':[],'news':4},
 'sidebar':{'order':['ad','traktir','info'],'off':[]},
 'info':{'title':'Informasi','links':[]},
 'traktir':{'url':'https://saweria.co/Bshantoz'},
 'ads':{'videos':[],'sticky':True},
 'social':[]}
def _lay():
    d=json.loads(json.dumps(LAY_DEF)); fp=ROOT+'/config/layout.json'
    if os.path.exists(fp):
        u=json.load(open(fp,encoding='utf8'))
        for k,v in u.items():
            if isinstance(v,dict) and isinstance(d.get(k),dict): d[k].update(v)
            else: d[k]=v
    return d
LAY=_lay()
def clean(c):
    c=re.sub(r'https?://(?:www\.)?qategori\.com','',c)
    return c
for it in items: it['content']=clean(it['content'])
from openacc import open_access
for it in items: it['content']=open_access(it['content'])
def _pt(x):
    try: return datetime.datetime.fromisoformat(x['pub'].replace('Z','+00:00')).astimezone(datetime.timezone.utc)
    except Exception: return datetime.datetime.min.replace(tzinfo=datetime.timezone.utc)
posts=sorted([i for i in items if i['type']=='POST'],key=lambda x:(_pt(x),x['path']),reverse=True)
pages=[i for i in items if i['type']=='PAGE']
def text_of(h):
    h=re.sub(r'(?is)<(script|style).*?</\1>','',h); h=re.sub(r'<[^>]+>',' ',h)
    return re.sub(r'\s+',' ',html.unescape(h)).strip()
def thumb(h):
    m=re.search(r'<img[^>]+src="([^"]+)"',h); return m.group(1) if m else ''
for it in items:
    it['text']=text_of(it['content'])
    it['d']=(it.get('desc') or it['text'][:160]).strip()
    it['th']=it.get('thumb') or thumb(it['content'])
    if it['th'].startswith('/') and not it['th'].startswith('//'): it['th']=DOMAIN+it['th']
def esc(x): return html.escape(x or '',quote=True)
def dfmt(p):
    d=datetime.datetime.fromisoformat(p.replace('Z','+00:00'))
    M=['Jan','Feb','Mar','Apr','Mei','Jun','Jul','Agu','Sep','Okt','Nov','Des']
    return f'{d.day} {M[d.month-1]} {d.year}'

IC0={
'bushu':'<path d="M3 5H15M9 3V5M10.0482 14.5C8.52083 12.9178 7.28073 11.0565 6.41187 9M12.5 18H19.5M11 21L16 11L21 21M12.7511 5C11.7831 10.7702 8.06969 15.6095 3 18.129"/>',
'belajar':'<path d="M22 16.74V4.67C22 3.47 21.02 2.58 19.83 2.68H19.77C17.67 2.86 14.48 3.93 12.7 5.05L12.53 5.16C12.24 5.34 11.76 5.34 11.47 5.16L11.22 5.01C9.44 3.9 6.26 2.84 4.16 2.67C2.97 2.57 2 3.47 2 4.66V16.74C2 17.7 2.78 18.6 3.74 18.72L4.03 18.76C6.2 19.05 9.55 20.15 11.47 21.2L11.51 21.22C11.78 21.37 12.21 21.37 12.47 21.22C14.39 20.16 17.75 19.05 19.93 18.76L20.26 18.72C21.22 18.6 22 17.7 22 16.74Z"/><path d="M12 5.49V20.49"/>',
'podcast':'<path d="M12 3a3 3 0 0 0-3 3v6a3 3 0 0 0 6 0V6a3 3 0 0 0-3-3Z"/><path d="M5 11a7 7 0 0 0 14 0M12 18v3M9 21h6"/>',
'game':'<rect x="2.5" y="7" width="19" height="11" rx="4"/><path d="M7.5 10.5v4M5.5 12.5h4M15.5 11.5h.01M18 13.5h.01"/>',
'berita':'<path d="M8.5 19H8C4 19 2 18 2 13V8C2 4 4 2 8 2H16C20 2 22 4 22 8V13C22 17 20 19 16 19H15.5C15.19 19 14.89 19.15 14.7 19.4L13.2 21.4C12.54 22.28 11.46 22.28 10.8 21.4L9.3 19.4C9.14 19.18 8.77 19 8.5 19Z"/><path d="M7 8h10M7 12h6"/>',
'search':'<circle cx="11" cy="11" r="7"/><path d="M20 20l-3.5-3.5"/>',
'moon':'<path d="M20 14.5A8 8 0 1 1 9.5 4a6.5 6.5 0 0 0 10.5 10.5Z"/>'}
# ikon asli dari tema (qnv IC berisi podcast, belajar, menu, game, berita)
_L=[l for l in t.split('\n') if l.strip().startswith('var IC = {"podcast"')][0]
ICO=json.loads(_L[_L.index('{'):_L.rindex('}')+1])
_m=re.search(r"bushu: '(<svg class=\"line\".*?</svg>)'",t); ICO['bushu']=_m.group(1)
def svg(k): return ICO[k]
IC=IC0
def _old_svg(k): return f'<svg class="line" viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">{IC[k]}</svg>'
TABS=[('bushu','Bushu'),('belajar','Belajar'),('podcast','Podcast'),('game','Game'),('berita','Berita')]


# ---------- JS dari tema ----------
TL=t.split('\n')
def L(n): return TL[n-1]
def seg(start_pat,end_pat,frm=0):
    i=t.index(start_pat,frm); j=t.index(end_pat,i)+len(end_pat); return t[i:j]
GAMES=seg('var GAMES = [','\n  ];')[len('var GAMES = '):]
SUBTABS=t[t.index('  var SI = {'):t.index("subtree: true});",t.index('  var SI = {'))+len("subtree: true});")]
_c=t.index('  var CITIES = ')
TODAY=t[t.index("  var todayEl = document.createElement('section');",_c-3000):t.index("  /* Pilihan lama \"Berita Teknologi")]
CITIES_LINE=t[_c:t.index('\n',_c)]
HARI=t[t.index("  var HARI = "):t.index("  var todayEl = document.createElement('section');")]
READSET=t[t.index("  var KLV = ["):t.index("  function showKotoba")]
today_js=CITIES_LINE+'\n'+HARI.replace(CITIES_LINE,'')+TODAY+READSET
# blok mandiri: qDaily, suasana (audio+fx), pemandangan, Mochi, tombol Menu PC
lines=t.split('\n')
def block(first_line_no):  # ambil dari "(function(){" sampai "})();" pertama setelahnya di kolom 0
    k=first_line_no-1
    while not lines[k].startswith('})();'): k+=1
    return '\n'.join(lines[first_line_no-1:k+1])
def find_line(prefix,after=0):
    for i in range(after,len(lines)):
        if lines[i].startswith(prefix): return i+1
b_daily=block(find_line('(function(){',6200))
i_fx=[i for i,l in enumerate(lines) if '/* Suasana: efek musim' in l][0]
b_fx=block(i_fx-1)
b_scene=block(find_line('(function(){',i_fx+1))
b_scene=b_scene.replace("var hdrEl, ftrEl, bodyEl, fl = [], fr = [];","var hdrEl, ftrEl, botEl, bodyEl, fl = [], fr = [];")
b_scene=b_scene.replace("    if (!bodyEl) {\n      bodyEl = document.createElement","    var bn = document.querySelector('.qBottom');\n    if (bn && !botEl) { botEl = document.createElement('div'); botEl.className = 'qsBot'; botEl.setAttribute('aria-hidden', 'true'); bn.insertBefore(botEl, bn.firstChild); }\n    if (!bodyEl) {\n      bodyEl = document.createElement",1)
b_scene=b_scene.replace("    if (bodyEl) {\n      if (on) { bodyEl.firstChild","    if (botEl) {\n      if (on) { botEl.innerHTML = '<svg class=\"qsBs\" viewBox=\"0 0 400 60\" preserveAspectRatio=\"xMidYMid slice\"><g class=\"qsN\">' + stars(400, 40, 16) + '</g></svg><div class=\"qsGr\"></div>'; botEl.querySelector('.qsGr').style.backgroundImage = uri(grassTile(s, p)); }\n      else botEl.innerHTML = '';\n    }\n    if (bodyEl) {\n      if (on) { bodyEl.firstChild",1)
assert "botEl.className" in b_scene and "qsBs" in b_scene

b_cat=block(find_line('(function(){',find_line('(function(){',i_fx+1)))
i_qnv=[i for i,l in enumerate(lines) if 'PC: tombol Menu melayang' in l][0]
b_qnv=block(i_qnv-1)
b_fx=b_fx.replace("fx: 'off'","fx: 'aki'",1)
b_ad=block(find_line('(function(){',6956))
assert "if (e.animationName !== 'qAdIn') return;" in b_ad
b_ad=b_ad.replace("if (e.animationName !== 'qAdIn') return;","return; /* HP: tidak putar otomatis, sama seperti PC (tunggu ketuk) */")
def inc(name):
    m=re.search(r"<b:includable id='%s'[^>]*>(.*?)</b:includable>"%name,t,re.S); return re.sub(r'<!--.*?-->','',m.group(1).strip(),flags=re.S)
b_prof=block(find_line('(function(){',6440))
_o="    if (nm) nm.textContent = 'Masuk';"
assert _o in b_prof
b_prof=b_prof.replace(_o,"    var bav = el('qbAv'); if (bav) { if (!bav.__d) bav.__d = bav.innerHTML; if (user && user.photoURL) bav.innerHTML = '<img alt=\"\" referrerpolicy=\"no-referrer\" src=\"' + esc(user.photoURL) + '\"/>'; else if (user && first) bav.innerHTML = '<b class=\"qbIni\">' + esc(first.charAt(0).toUpperCase()) + '</b>'; else bav.innerHTML = bav.__d; }\n"+_o,1)

import json as _j
DELSVG=re.search(r"deleteText: '(<svg.*?</svg>)'",t,re.S).group(1)
OWN=open(ROOT+'/own.js',encoding='utf8').read().replace('/*DELSVG*/',_j.dumps(DELSVG)).replace('/*BMSVG*/',_j.dumps(inc('archive-add-icon')+inc('archive-tick-icon')))
theme_js="\n".join(['/* disalin dari tema Blogger */',b_daily,b_fx,b_scene,b_cat,b_qnv,b_ad,b_prof,OWN])
open(OUT+'/theme.js','w',encoding='utf8').write(theme_js)
appjs=open(ROOT+'/app.js',encoding='utf8').read().replace('/*LAYOUT*/','var QL='+json.dumps({'home':LAY['home']},ensure_ascii=False)+';').replace('/*GAMES*/',GAMES).replace('/*SUBTABS*/',SUBTABS).replace('/*TODAY*/',today_js)
open(OUT+'/app.js','w',encoding='utf8').write(appjs)
_arrow=re.search(r"<path[^>]*d=['\"]([^'\"]+)['\"]",inc('arrow-left-1-icon'))
_svg=('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="black" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="%s"/></svg>'%_arrow.group(1)) if _arrow else ''
import urllib.parse as _u
_uri='data:image/svg+xml,'+_u.quote(_svg)
CLOSE_CSS='''
.leftF{justify-content:flex-start!important}
.leftF label{min-width:56px!important;justify-content:flex-start!important;padding-inline:var(--contentPadding,16px)!important}
.leftF label::before{content:''!important;display:block;width:24px;height:24px;background:currentColor;-webkit-mask:url("'''+_uri+'''") center/contain no-repeat;mask:url("'''+_uri+'''") center/contain no-repeat}

/* tombol tutup popup: tanda panah kembali, seperti popup penanda */
.popUp .popH .c{justify-content:flex-start!important;min-width:44px}
.popUp .popH .c:not(.r){right:auto!important;left:var(--contentPadding)}
.popUp .popH .c.r{left:auto!important;right:var(--contentPadding)}
.popUp .popH .c::after{content:''!important;display:block;width:24px;height:24px;background:currentColor;-webkit-mask:url("'''+_uri+'''") center/contain no-repeat;mask:url("'''+_uri+'''") center/contain no-repeat}
'''
open(OUT+'/site.css','w',encoding='utf8').write(open(ROOT+'/site.css',encoding='utf8').read()+CLOSE_CSS)

THEME_BOOT="<script>(function(){try{var m=localStorage.getItem('q_theme');if(m==='dark'||m==='light')document.documentElement.setAttribute('data-q',m)}catch(e){}})()</script>"
LOGO='https://raw.githubusercontent.com/bshantoz/qategori/refs/heads/logo/'
HOME_OG_T='Qategori | Update berita teknologi terkini!'
HOME_OG_D='Update teknologi 2026: Android 17, iOS, review gadget, tips smartphone, dan game PC/konsol. Baca tiap hari.'
def ttl(raw):  # aturan judul sama seperti tema Blogger
    return raw if len(raw)+len(NAME)>57 else raw+' - '+NAME
def head(title,desc,path,extra='',og='website',img='',home=False):
    canon=DOMAIN+path
    ogt=HOME_OG_T if home else title; ogd=HOME_OG_D if home else desc[:300]
    im=img or LOGO+'logo-1200x600.png'
    return f'''<!doctype html><html lang="id"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<title>{esc(title)}</title><meta name="description" content="{esc(desc[:300])}"><meta name="keywords" content="{esc(title)}"><meta name="robots" content="max-image-preview:large"><link rel="canonical" href="{canon}">
<meta property="og:type" content="{og}"><meta property="og:title" content="{esc(ogt)}"><meta property="og:description" content="{esc(ogd)}"><meta property="og:url" content="{canon}"><meta property="og:site_name" content="{NAME}"><meta property="og:image" content="{esc(im)}"><meta property="og:logo" content="{LOGO}icons-512.png">
<meta property="og:locale" content="id_ID"><meta property="og:locale:alternate" content="en_US"><meta property="article:author" content="https://www.facebook.com/qategori"><meta property="article:publisher" content="https://www.facebook.com/qategori"><meta property="fb:admins" content="qategori.info">
<meta name="twitter:card" content="summary_large_image"><meta name="twitter:site" content="@bshantoz"><meta name="twitter:title" content="{esc(ogt)}"><meta name="twitter:description" content="{esc(ogd)}"><meta name="twitter:image" content="{esc(im)}">
<meta name="application-name" content="Qategori"><meta name="theme-color" content="#ffffff"><meta name="msapplication-TileColor" content="#da532c"><meta name="apple-mobile-web-app-capable" content="true">
<link rel="icon" href="/favicon.ico" type="image/x-icon"><link rel="shortcut icon" href="/favicon.ico" type="image/x-icon"><link rel="icon" href="{LOGO}favicon.ico" sizes="32x32"><link rel="apple-touch-icon" href="{LOGO}apple-touch-icon.png" sizes="180x180"><link rel="icon" href="{LOGO}android-chrome-192x192.png" sizes="192x192" type="image/png"><link rel="manifest" href="{LOGO}site.webmanifest"><link rel="mask-icon" href="{LOGO}safari-pinned-tab.svg" color="#5bbad5">
<link rel="stylesheet" href="/base.css"><link rel="stylesheet" href="/site.css">{THEME_BOOT}
<script async src="https://www.googletagmanager.com/gtag/js?id={GA}"></script><script>window.dataLayer=window.dataLayer||[];function gtag(){{dataLayer.push(arguments)}}gtag('js',new Date());gtag('config','{GA}');</script>
{extra}</head>'''
def _cdata(widget_id):
    i=t.index("id='%s' locked='false'"%widget_id); j=t.index('<![CDATA[',i)+9; k=t.index(']]></b:widget-setting>',j)
    return t[j:k]
def _cd2(wid):
    i=t.index("id='%s'"%wid); j=t.index('<![CDATA[',i)+9; k=t.index(']]></b:widget-setting>',j); return t[j:k]
WHISKAS=_cdata('HTML3'); INFO=_cdata('HTML2'); AD99=_cd2('HTML99'); AD95=_cd2('HTML95')

# ---------- terapkan layout dari CMS ----------
def _vid(x):
    x=(x or '').strip(); m=re.search(r'(?:v=|youtu\.be/|embed/|shorts/)([\w-]{11})',x)
    return m.group(1) if m else (x if re.fullmatch(r'[\w-]{11}',x) else '')
_vids=[v for v in (_vid(x) for x in LAY['ads'].get('videos',[])) if v]
if _vids:
    AD99=re.sub(r'data-videos="[^"]*"','data-videos="%s"'%','.join(_vids),AD99)
    AD95=re.sub(r'data-videos="[^"]*"','data-videos="%s"'%','.join(_vids),AD95)
    AD99=re.sub(r'/embed/[\w-]{11}','/embed/'+_vids[0],AD99); AD95=re.sub(r'/embed/[\w-]{11}','/embed/'+_vids[0],AD95)
_il=[l for l in LAY['info'].get('links',[]) if l.get('label') and l.get('url')]
if _il:
    _inf='<b>'+html.escape(LAY['info'].get('title') or 'Informasi')+'</b>\n<div>\n'+'\n'.join('<a href="%s">%s</a>'%(html.escape(l['url'],quote=True),html.escape(l['label'])) for l in _il)+'\n</div>\n</nav>'
    INFO,_n=re.subn(r'<b>[^<]*</b>\s*<div>.*?</div>\s*</nav>',lambda m:_inf,INFO,flags=re.S); assert _n==1
_tu=(LAY['traktir'].get('url') or '').strip()
if _tu: WHISKAS=WHISKAS.replace('href="https://saweria.co/Bshantoz"','href="%s"'%html.escape(_tu,quote=True),1)
_SW={'ad':'<div id="HTML95" class="widget HTML">'+AD95+'</div>','traktir':WHISKAS,'info':INFO}
SIDE=''.join(_SW[k] for k in LAY['sidebar']['order'] if k in _SW and k not in LAY['sidebar'].get('off',[]))
ANCHOR=('<section class="noPrint" id="anchor-ad"><div id="HTML99" class="widget HTML"><details class="stickAd" open=""><summary aria-label="Close ad" class="flex center n"></summary><div class="stickC">'+AD99+'</div></details></div></section>') if LAY['ads'].get('sticky',True) else ''
def inc(name):
    m=re.search(r"<b:includable id='%s'[^>]*>(.*?)</b:includable>"%name,t,re.S); return re.sub(r'<!--.*?-->','',m.group(1).strip(),flags=re.S)
def selfclose(h): return re.sub(r"<(span|label|div|a|i)([^>]*?)\s*/>",r"<\1\2></\1>",h)
# menu kiri asli
_seg='\n'.join(TL[2993:3250]); LEFT=[]
for m in re.finditer(r"<li class='(leftC[^']*)'>(.*?)</li>",_seg,re.S):
    cls,b=m.group(1),m.group(2)
    if 'qpMenuLi' in cls or 'data:link.target' in b: continue
    href=(re.search(r"href='([^']*)'",b) or [None,'/'])[1]
    _n=re.search(r"<div class='n text'>\s*<span[^>]*>([^<]*)</span>",b,re.S)
    nm=_n.group(1).strip() if _n else ('Beranda' if 'home-icon' in b else None)
    if not nm:
        _l=re.search(r"aria-label='([^']*)'",b); nm=_l.group(1) if _l else None
    if not nm: continue
    nm={'<data:messages.home/>':'Beranda','About':'Tentang Kami','Contact':'Hubungi Kami'}.get(nm,nm)
    sv=re.search(r"<svg.*?</svg>",b,re.S); ic=sv.group(0) if sv else inc(re.search(r"b:include name='([^']*)'",b).group(1))
    href={'/search/label/Berita':'/search/label/Berita/','/search/label/Android':'/search/label/Android/','/search/label/Aplikasi':'/search/label/Aplikasi/','/search/label/Tips%20Japan':'/search/label/Tips%20Japan/'}.get(href,href)
    ext=' target="_blank" rel="noopener"' if 'target=' in b else ''
    arrow='<span class="x">&#8599;</span>' if ext else ''
    LEFT.append(f'<li class="{cls}"><a aria-label="{nm}" class="a flex op i20" href="{href}"{ext}>{ic}<div class="n text"><span>{nm}</span>{arrow}</div></a></li>')
LEFTP='<div class="leftP"><input class="proP hidden" id="forProfile" type="checkbox"><div class="profileIcon leftC flex solo"><label aria-label="Profil dan progres" class="a flexIn fc qpOpen" for="forProfil"><span class="avi flex center op i20" id="qpAv">'+inc("profile-circle-icon")+'</span><span class="n flex column"><span class="fontS" id="qpName">Masuk</span></span></label></div></div>'
PROFPOP='<div class="shared"><input class="popI hidden" id="forProfil" type="checkbox"><div class="shareB popUp"><div class="popIn n"><div class="popC"><div class="popH flex"><span class="t" data-text="Profil &amp; Progres"></span><label aria-label="Close" class="c" for="forProfil"></label></div><div class="shareI flex column qpBody" id="qpBody"></div><input accept="application/json,.json" class="hidden" id="qpFile" type="file"></div></div><label class="fc" for="forProfil"></label></div></div>'
# popup Belajar asli
_p=t[t.index("<div class='shared'>",t.index('Popup menu bawah: &#26085;')):]
_p=_p[:_p.index('</div>\n                        </div>\n\n                        <script>')+len('</div>\n                        </div>')]
POPUP=selfclose(_p)
SRCH=inc('search-icon')

def _tm(cls,name,inner): return f'<span class="fontM {cls}" data-text="{name}" role="button" aria-label="{name}" onclick="setTheme(\'{inner}\')"><span class="i{" rev" if cls=="D" else ""} flex {cls.lower() if cls!="A" else "a"}"><span class="c"><span class="k flex column"><i class="t flex"></i><i class="p flex column"></i></span></span>{"<span class=\"c rev\"><span class=\"k flex column\"><i class=\"t flex\"></i><i class=\"p flex column\"></i></span></span>" if cls=="A" else ""}</span></span>'
SETTB=('<div class="settB"><div class="iTheme ipopUp flex column invisible"><label class="h flexIn fontS opacity i14" aria-label="Tema" data-text="Tema" for="forDark">'+inc("arrow-left-1-icon")+'</label><div class="inn flex fontS">'
  +_tm("A","Sistem","default")+_tm("D","Gelap","dark")+_tm("L","Terang","light")+'<span class="fontM opacity" data-text="Pilih tampilan"></span></div></div>'
  +'<div class="iBook ipopUp flex column invisible"><label class="h flexIn fontS opacity i14" aria-label="Penanda" data-text="Penanda" for="forBook">'+inc("arrow-left-1-icon")+'</label><div class="bookmark-inner flex column"></div></div></div>')
TAGSVG='<svg class="line" viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M4.16989 15.3L8.69989 19.83C10.5599 21.69 13.5799 21.69 15.4499 19.83L19.8399 15.44C21.6999 13.58 21.6999 10.56 19.8399 8.69005L15.2999 4.17005C14.3499 3.22005 13.0399 2.71005 11.6999 2.78005L6.69989 3.02005C4.69989 3.11005 3.10989 4.70005 3.00989 6.69005L2.76989 11.69C2.70989 13.04 3.21989 14.35 4.16989 15.3Z"/><circle cx="9.5" cy="9.5" r="2.5"/></svg>'
BMSVG=inc("archive-add-icon")+inc("archive-tick-icon")
def bmbtn(po): 
    pid=re.sub(r'\W','',po['path'])[-24:]
    return f'<div class="ignielBookmarkPost tag addl"><input class="hidden addb" id="bm-{pid}" name="bookmark" type="checkbox"><label aria-label="Tambah penanda" class="flex center op i16" data-img="{esc(po["th"] or "")}" data-title="{esc(po["title"])}" data-url="{po["path"]}" for="bm-{pid}">{BMSVG}</label></div>'
_SOC=[(x.get('name') or x['icon'],x['url'],x['icon']+'-i-icon') for x in LAY.get('social',[]) if x.get('url') and x.get('icon')] or [('Youtube','https://youtube.com/@qategori_','youtube-i-icon'),('Facebook','https://www.facebook.com/Qategori/','facebook-i-icon'),('Instagram','https://www.instagram.com/flornauna/','instagram-i-icon')]
SOCIALS=''.join(f'<a class="ic op i20" aria-label="{html.escape(n,quote=True)}" href="{html.escape(u,quote=True)}" target="_blank" rel="noopener" role="button">{inc(i)}</a>' for n,u,i in _SOC)
PROFSVG='<svg class="line" viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="8" r="4"/><path d="M4 21c0-4.4 3.6-7 8-7s8 2.6 8 7"/></svg>'
def chrome(inner,active='',cls=''):
    bot=''.join((f'<label class="qbMenu qpOpen" for="forProfil" aria-label="Profil saya"><span class="qbAv" id="qbAv">{PROFSVG}</span><span id="qbProfName">Profil</span></label>' if k=='menu' else f'<a href="/#{k}" class="{"on" if k==active else ""}" data-tab="{k}">{svg(k)}<span>{n}</span></a>') for k,n in [('podcast','Podcast'),('belajar','Belajar'),('menu','Menu'),('game','Game'),('berita','Berita')])
    return f"""<body class="nB {cls}" data-theme="default"><input class="navi hidden" id="forNav" type="checkbox">
<div class="mainW"><header class="mainH flex cInherit noPrint"><div class="headL flex shrink"><div class="headi menu flex center"><label aria-label="Open menu" class="mc fc ic op i20" for="forNav">{inc('menu-2-icon')}</label></div>
<div class="headT notranslate"><div class="headI"><h1 class="headN"><a class="headt ellips" href="/">Qategori</a></h1></div></div></div>
<div class="headR flex shrink"><div class="headS"><form class="srh fontM" action="/search/" method="get" role="search"><input autocomplete="off" class="shI bgInherit fontBa ellips" id="forSearch" name="q" placeholder="Kata kunci" aria-label="Cari" type="search"><button class="b ba bgInherit flex center op i18" aria-label="Cari" type="submit">{SRCH}</button></form></div>
<div class="headB"><input class="setI hidden" id="forSettings" type="checkbox"><input class="proI hidden" id="forUsers" type="checkbox"><input class="darkI hidden" id="forDark" type="checkbox"><input class="bookI hidden" id="forBook" type="checkbox"><div class="section" id="header-icon"><div class="headi flex"><a class="sc ic op i20" aria-label="Search" href="/search/">{SRCH}</a><label class="dc fc ic op i20" aria-label="Tema" for="forDark">{inc("moon-n-sun-2-icon")}</label><div class="ignielBookmark ibook"><label class="bc fc ic op i20" data-text="0" aria-label="Penanda" for="forBook">{inc("frame-icon")}</label></div></div></div>{SETTB}</div></div></header>
<div class="mainN flex"><div class="mainL noPrint shrink"><div class="leftW flex cInherit"><div class="leftN"><div class="leftM"><ul class="leftNav flex column noList">{''.join(LEFT)}</ul></div>{LEFTP}
<div class="leftF leftC hidden fontM"><label aria-label="Close menu" class="flexIn" for="forNav"></label></div></div></div></div>
<div class="mainR flex column grow"><div class="mainC"><div class="maxC"><div class="mainB flex wrap"><main class="blogB grow">{inner}</main>
<aside class="sideB"><div class="qSideIn"><div class="sideSticky flex column">{SIDE}</div></div></aside></div></div></div>
<footer class="mainF qFoot"><div class="qFootR flex"><div class="bT flex fontS noWrap opacity i14" data-text="Atas" role="button" onclick="window.scrollTo({{top:0}})">{inc("arrow-up-1-icon")}</div><div class="socials flex">{SOCIALS}</div></div><p>&copy; {datetime.date.today().year} Qategori</p></footer></div></div></div>
{POPUP}{PROFPOP}
{ANCHOR}
<nav class="qBottom" aria-label="Menu bawah">{bot}</nav><script src="/app.js"></script><script src="/theme.js"></script></body></html>"""
def write(path,content):
    fp=OUT+path
    if path.endswith('/'): fp+='index.html'
    os.makedirs(os.path.dirname(fp),exist_ok=True)
    open(fp,'w',encoding='utf8').write(content)

HIDL=re.compile(r'^(Product|Discount[1-9]0)$')
def vis(ls): return [l for l in ls if not HIDL.match(l)]
def badges(p):
    if 'Product' not in p['labels']: return ''
    d=[l for l in p['labels'] if re.match(r'^Discount[1-9]0$',l)]
    return '<div class="qBar"><span class="qTag">'+TAGSVG+'</span>'+(f'<span class="qDisc">-{d[0][8:]}%</span>' if d else '')+'</div>'
def labels_html(ls): ls=vis(ls); return ''.join(f'<a class="qLab" href="/search/label/{urllib.parse.quote(l)}/">{esc(l)}</a>' for l in ls)
def card(p):
    return card0(p).replace('</article>',bmbtn(p)+'</article>')
def card0(p):
    th=f'<img src="{esc(p["th"])}" alt="" loading="lazy">' if p['th'] else '<span class="qNoImg"></span>'
    return f'<article class="qCard"><a class="qThumb" href="{p["path"]}">{th}</a><div><h3><a href="{p["path"]}">{esc(p["title"])}</a></h3><p>{esc(p["d"][:140])}</p><small>{dfmt(p["pub"])}{(" · "+esc(vis(p["labels"])[0])) if vis(p["labels"]) else ""}</small></div></article>'


def share_html(po):
    u=DOMAIN+po['path']; q=urllib.parse.quote(u,safe='')
    items=[('Facebook','https://www.facebook.com/sharer.php?u='+q,'facebook-i-icon'),('Whatsapp','https://api.whatsapp.com/send?text='+q,'whatsapp-i-icon'),('Twitter','https://twitter.com/share?url='+q,'twitter-i-icon'),('Telegram','https://t.me/share/url?url='+q,'telegram-i-icon'),('Pinterest','https://pinterest.com/pin/create/button/?url='+q+'&media='+urllib.parse.quote(po['th'] or '',safe=''),'pinterest-i-icon'),('LinkedIn','https://www.linkedin.com/sharing/share-offsite/?url='+q,'linkedin-i-icon'),('Tumblr','https://www.tumblr.com/share/link?url='+q,'tumblr-i-icon'),('Line','https://timeline.line.me/social-plugin/share?url='+q,'line-i-icon'),('Email','mailto:?body='+q,'sms-edit-icon')]
    links=''.join(f'<div data-text="{n}"><a aria-label="{n}" class="flex center op" href="{h}" rel="noopener" role="button" target="_blank" title="{n}">{inc(ic)}</a></div>' for n,h,ic in items)
    return f'<div class="shared"><input class="popI hidden" id="forShare" type="checkbox"><div class="shareB popUp"><div class="popIn n"><div class="popC"><div class="popH flex"><span class="t" data-text="Bagikan ke aplikasi lain"></span><label aria-label="Tutup" class="c" for="forShare"></label></div><div class="shareI flex column"><div class="shareL cInherit fontSm">{links}</div><div class="shareC" data-text="Salin tautan"><div class="copy flex op i18"><input value="{u}" id="getLink" readonly onclick="this.select()"><label aria-label="Salin tautan" for="getLink" data-copy="1">Salin</label></div></div></div></div></div><label class="fc" for="forShare"></label></div></div>'
def share_btn(): return '<label aria-label="Bagikan" class="qShare flex center opacity i20" for="forShare">'+inc('share-icon')+'</label>'

for pg in pages:
    p=pg['path']
    if p=='/p/sitemap.html':
        lst='<h2>Halaman</h2><ul>'+''.join(f'<li><a href="{x["path"]}">{esc(x["title"])}</a></li>' for x in sorted(pages,key=lambda x:x['title'].lower()) if x['path'] not in('/p/admin.html','/p/sitemap.html'))+'</ul><h2>Artikel</h2><ul>'+''.join(f'<li><a href="{x["path"]}">{esc(x["title"])}</a> <small>{dfmt(x["pub"])}</small></li>' for x in posts)+'</ul>'
        body=f'<div class="postBody pE">{lst}</div>'
    else:
        body=f'<div class="postBody pE">{pg["content"]}</div>'
    robots='<meta name="robots" content="noindex">' if p in('/p/admin.html','/p/bookmark.html') else ''
    h=head(ttl(pg['title']),(pg['d'] or DESC_SITE)[:147],p,robots)
    write(p,h+chrome(f'<article class="qPage"><h1 class="qPT">{esc(pg["title"])}</h1>{body}</article>',cls='qpage'))
for po in posts:
    h=head(ttl(po['title']),po['d'][:147],po['path'],f'<meta property="article:published_time" content="{po["pub"]}">',og='article',img=po['th'])
    ld=json.dumps({"@context":"https://schema.org","@type":"BlogPosting","headline":po['title'],"datePublished":po['pub'],"dateModified":po.get('upd') or po['pub'],"description":po['d'],"mainEntityOfPage":DOMAIN+po['path'],"image":po['th'] or None,"author":{"@type":"Person","name":"Ben"}},ensure_ascii=False)
    h=h.replace('</head>',f'<script type="application/ld+json">{ld}</script></head>')
    rel=[x for x in posts if x is not po and set(x['labels'])&set(po['labels'])][:6]
    relh=('<section class="qRel"><h2>Artikel terkait</h2>'+''.join(card(x) for x in rel)+'</section>') if rel else ''
    body=f'<article class="qPost"><header><h1>{esc(po["title"])}</h1><div class="qRow"><span class="qMeta">{dfmt(po["pub"])}</span><div class="qAct">{bmbtn(po)}{share_btn()}</div></div><p class="qMeta qLabs2">{labels_html(po["labels"])}</p>{share_html(po)}</header><div class="postBody pE" itemprop="articleBody">{po["content"]}</div></article>{relh}'
    write(po['path'],h+chrome(body,'berita'))
labs={}
for po in posts:
    for l in po['labels']: labs.setdefault(l,[]).append(po)
for l,ps in labs.items():
    path='/search/label/'+urllib.parse.quote(l)+'/'
    h=head(f'{l} - {NAME}',f'Artikel berlabel {l} di {NAME}.',path)
    write(path,h+chrome(f'<section class="qList"><h1>Label: {esc(l)}</h1>'+''.join(card(x) for x in ps)+'</section>','berita'))
idx=[{'t':x['title'],'p':x['path'],'l':x['labels'],'d':x['d'][:140],'tx':x['text'][:1500].lower(),'dt':x['pub'][:10],'th':x['th'],'ty':x['type']} for x in posts+[q for q in pages if q['path'] not in('/p/admin.html','/p/bookmark.html','/p/sitemap.html')]]
json.dump(idx,open(OUT+'/search.json','w',encoding='utf8'),ensure_ascii=False,separators=(',',':'))
write('/search/',head('Pencarian - '+NAME,'Cari artikel dan materi di '+NAME,'/search/','<meta name="robots" content="noindex">')+chrome('<section class="qList"><h1>Hasil pencarian</h1><form class="srh qSearch2" action="/search/" method="get"><input type="search" name="q" placeholder="Kata kunci" aria-label="Cari"><button class="qhBtn">Cari</button></form><div id="qRes"><p>Memuat...</p></div></section>','berita',cls='qsearch'))
write('/404.html',head('Error 404: Tidak ditemukan!','Halaman tidak ditemukan','/404.html','<meta name="robots" content="noindex">')+chrome('<section class="qPage"><h1>Halaman tidak ditemukan</h1><p>Alamat yang kamu buka tidak ada. Coba <a href="/">beranda</a> atau cari di kolom atas.</p></section>'))
home_list=''.join(card(x) for x in posts[:20])
chips=''.join(f'<button type="button" class="qChip" data-lab="{esc(l)}">{esc(l)}</button>' for l,_ in sorted(labs.items(),key=lambda kv:-len(kv[1]))[:12])
home_body=f'''<section id="qHome" class="qh" data-home="1"><div class="qhPane" data-pane="berita" hidden><div class="qhList" id="qList">{home_list}</div><button type="button" class="qMore" id="qMore">Muat postingan lainnya</button><div id="qExtra"></div></div></section>
<noscript><nav><h2>Materi</h2><ul><li><a href="/p/materi-dan-kuis-kanji-metode-bushu.html">Bushu</a></li><li><a href="/p/jawa.html">Jawa</a></li><li><a href="/p/sunda.html">Sunda</a></li><li><a href="/p/bali.html">Bali</a></li><li><a href="/p/level-materi-jlpt.html">JLPT</a></li><li><a href="/p/podcast.html">Podcast</a></li><li><a href="/p/permainan.html">Game</a></li></ul></nav></noscript>'''
write('/',head(NAME,DESC_SITE,'/',home=True)+chrome(home_body,'bushu',cls='home'))
urls=['/']+[x['path'] for x in pages if x['path'] not in('/p/admin.html','/p/bookmark.html')]+[x['path'] for x in posts]
sm='<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">'
bypath={x['path']:x for x in items}
for u in urls:
    lm=(bypath[u].get('upd') or bypath[u]['pub'])[:10] if u in bypath else datetime.date.today().isoformat()
    sm+=f'<url><loc>{DOMAIN}{u}</loc><lastmod>{lm}</lastmod></url>'
sm+='</urlset>'
write('/sitemap.xml',sm)
pgu=[x['path'] for x in pages if x['path'] not in('/p/admin.html','/p/bookmark.html','/p/sitemap.html')]
write('/sitemap-pages.xml','<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">'+''.join(f'<url><loc>{DOMAIN}{u}</loc></url>' for u in pgu)+'</urlset>')
def fent(x): return {"id":{"$t":"tag:qategori.com,"+x['path']},"published":{"$t":x['pub']},"updated":{"$t":x.get('upd') or x['pub']},"title":{"$t":x['title']},"link":[{"rel":"alternate","type":"text/html","href":DOMAIN+x['path']}],"category":[{"term":l} for l in x['labels']]}
feed={"version":"1.0","encoding":"UTF-8","feed":{"title":{"$t":NAME},"openSearch$totalResults":{"$t":str(len(posts))},"entry":[fent(x) for x in posts[:25]]}}
write('/feeds/posts/default',json.dumps(feed,ensure_ascii=False))
write('/robots.txt',f'User-agent: *\nAllow: /\nDisallow: /search/?\n\nSitemap: {DOMAIN}/sitemap.xml\n')
shutil.copy(ROOT+'/assets/favicon.ico',OUT+'/favicon.ico')
for _d,_t in (('content/img','img'),('admin','admin')):
    if os.path.isdir(ROOT+'/'+_d): shutil.copytree(ROOT+'/'+_d,OUT+'/'+_t,dirs_exist_ok=True)
open(OUT+'/CNAME','w').write(DOMAIN.split('//')[1]+'\n'); open(OUT+'/.nojekyll','w').write('')
print('ok',len(posts),len(pages),len(labs),sum(os.path.getsize(os.path.join(dp,f)) for dp,_,fs in os.walk(OUT) for f in fs)//1024,'KB')
